


library(readr)
library(janitor)
library(dplyr)




# pregunta 1 --------------------------------------------------------------------------------------------



## Leer la BD --------------------------------------------------------------------------------------------




df <- read_delim("mayo-2023.csv", 
                        delim = ";", escape_double = FALSE, trim_ws = TRUE) %>% 
    janitor::clean_names()

View(df)


## Explorar ----------------------------------------------------------------------------------------------


# Explorar la estructura de la base de datos
str(df)

# transformar a factor las variables: tamano, categoria, sexo y grupo

df$tamano <- factor(df$tamano)
df$categoria <- factor(df$categoria)
df$sexo <- factor(df$sexo)
df$grupo <- factor(df$grupo)


# Resumen de variables numéricas
summary(df[, sapply(df, is.numeric)])

# Resumen de variables categóricas
summary(df[, sapply(df, is.factor)])

# Calcular el número total de registros en la tabla
num_registros <- nrow(df)
print(num_registros)

# ¿Cuál es el número total de registros en la tabla?
# Hay 31626 registros en la tabla



# pregunta 2 --------------------------------------------------------------------------------------------

# Crear las nuevas variables multiplicadas por el factor de expansión
df <- df %>%
    mutate(
        nt_exp = nt * fe,
        rt_exp = rt * fe,
        ht_exp = ht * fe
    )

# Verificar el resultado
head(df)


# Calcular el salario promedio mensual por grupo ocupacional y tamaño de empresas

SalarioMensual <- df %>%
    group_by(grupo,tamano) %>%
    summarize(SalarioPromedio = mean(rt_exp, na.rm = TRUE))

# Verificar el resultado
print(SalarioMensual)

#visualizacion

library(ggplot2)

# Crear gráfico de barras
bar_plot <- ggplot(data = SalarioMensual, aes(x = grupo, y = SalarioPromedio, fill = tamano)) +
    geom_bar(stat = "identity", position = "dodge") +
    labs(x = "Grupo Ocupacional", y = "Salario Promedio Mensual") +
    theme_minimal()

print(bar_plot)






